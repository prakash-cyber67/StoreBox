const $=id=>document.getElementById(id);
const toast=msg=>{const t=$("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)};

$("openBtn").onclick=()=>{
 const code=$("code").value.trim();
 if(!code){toast("Enter a StoreBox code");return}
 $("activeCode").textContent=code;
 $("workspace").classList.remove("hidden");
 window.scrollTo({top:$("workspace").offsetTop,behavior:"smooth"});
 toast("StoreBox opened");
};

$("code").addEventListener("keydown",e=>{if(e.key==="Enter")$("openBtn").click()});

$("uploadBtn").onclick=()=>$("fileInput").click();
$("fileInput").onchange=()=>{
 [...$("fileInput").files].forEach(file=>addItem(file.name,"File",formatSize(file.size)));
 $("fileInput").value="";
};

function formatSize(bytes){
 if(bytes<1024)return bytes+" B";
 if(bytes<1024**2)return (bytes/1024).toFixed(1)+" KB";
 return (bytes/1024**2).toFixed(1)+" MB";
}
function addItem(name,type,size){
 const box=$("items");
 if(box.classList.contains("empty")){box.classList.remove("empty");box.innerHTML=""}
 const row=document.createElement("div");row.className="item";
 row.innerHTML=`<div class="item-info"><div class="item-icon">${type==="Text"?"T":"↑"}</div><div><b>${escapeHtml(name)}</b><small>${type} · ${size} · encrypted</small></div></div><button>Download</button>`;
 row.querySelector("button").onclick=()=>toast("Download will be connected to the encrypted storage backend");
 box.prepend(row);
 updateCount();
}
function updateCount(){$("count").textContent=`${document.querySelectorAll(".item").length} item${document.querySelectorAll(".item").length===1?"":"s"}`}

function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}

function openText(){ $("textPanel").classList.remove("hidden"); $("textTitle").focus() }
$("textBtn").onclick=openText;
$("closeText").onclick=()=> $("textPanel").classList.add("hidden");
$("cancelText").onclick=()=> $("textPanel").classList.add("hidden");
$("saveText").onclick=()=>{
 const title=$("textTitle").value.trim()||"Untitled Text";
 const text=$("textValue").value;
 if(!text.trim()){toast("Write some text first");return}
 addItem(title,"Text",text.length+" chars");
 $("textTitle").value="";$("textValue").value="";
 $("textPanel").classList.add("hidden");
 toast("Text encrypted and saved");
};
